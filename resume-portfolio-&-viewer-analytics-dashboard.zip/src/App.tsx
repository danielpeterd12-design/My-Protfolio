/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import ResumePortfolio from "./components/ResumePortfolio";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import { startSessionPingInterval, trackEvent } from "./utils/tracker";

export default function App() {
  const [currentView, setCurrentView] = useState<"portfolio" | "dashboard">("portfolio");

  // Track session heartbeat immediately on mount
  useEffect(() => {
    const cleanup = startSessionPingInterval();
    return () => cleanup();
  }, []);

  const handleNavigateToDashboard = () => {
    setCurrentView("dashboard");
    trackEvent("section_view", { section: "dashboard_entry" });
  };

  const handleBackToPortfolio = () => {
    setCurrentView("portfolio");
    trackEvent("section_view", { section: "dashboard_exit" });
  };

  return (
    <div id="app-root">
      {currentView === "portfolio" ? (
        <ResumePortfolio onNavigateToDashboard={handleNavigateToDashboard} />
      ) : (
        <AnalyticsDashboard onBackToPortfolio={handleBackToPortfolio} />
      )}
    </div>
  );
}
