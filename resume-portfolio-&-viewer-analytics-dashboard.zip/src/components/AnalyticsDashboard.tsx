/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { 
  BarChart3, 
  Users, 
  Eye, 
  Clock, 
  Download, 
  MessageSquare, 
  RefreshCw, 
  ArrowLeft, 
  Trash2, 
  Check, 
  Terminal, 
  Monitor, 
  Smartphone, 
  Tablet, 
  ShieldAlert,
  Mail,
  Zap,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { AnalyticsReport, ContactMessage } from "../types";

interface AnalyticsDashboardProps {
  onBackToPortfolio: () => void;
}

export default function AnalyticsDashboard({ onBackToPortfolio }: AnalyticsDashboardProps) {
  const [data, setData] = useState<AnalyticsReport | null>(null);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "messages" | "logs">("overview");
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);

  const fetchAnalytics = async () => {
    try {
      const [analyticsRes, messagesRes] = await Promise.all([
        fetch("/api/analytics/summary"),
        fetch("/api/contacts")
      ]);

      if (analyticsRes.ok && messagesRes.ok) {
        const analyticsData = await analyticsRes.json();
        const messagesData = await messagesRes.json();
        setData(analyticsData);
        setMessages(messagesData);
      }
    } catch (err) {
      console.error("Failed to fetch analytics data:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Poll for analytics every 5 seconds for absolute live real-time feel
  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(() => {
      fetchAnalytics();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchAnalytics();
  };

  const handleMarkAsRead = async (id: string) => {
    try {
      const res = await fetch(`/api/contacts/${id}/read`, { method: "PUT" });
      if (res.ok) {
        setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));
        if (data) {
          setData({
            ...data,
            summary: {
              ...data.summary,
              unreadMessages: Math.max(0, data.summary.unreadMessages - 1)
            }
          });
        }
      }
    } catch (err) {
      console.error("Error marking message as read:", err);
    }
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      const res = await fetch(`/api/contacts/${id}`, { method: "DELETE" });
      if (res.ok) {
        setMessages(prev => prev.filter(m => m.id !== id));
        if (selectedMessage === id) setSelectedMessage(null);
        if (data) {
          setData({
            ...data,
            summary: {
              ...data.summary,
              totalMessages: Math.max(0, data.summary.totalMessages - 1)
            }
          });
        }
      }
    } catch (err) {
      console.error("Error deleting message:", err);
    }
  };

  if (loading) {
    return (
      <div className="bg-slate-950 text-white min-h-screen flex flex-col justify-center items-center">
        <RefreshCw className="w-10 h-10 text-indigo-500 animate-spin mb-4" />
        <p className="font-mono text-slate-400 text-sm">Initializing Analytics Dashboard...</p>
      </div>
    );
  }

  const summary = data?.summary || {
    totalViews: 0,
    uniqueVisitors: 0,
    avgSessionDuration: "0.0",
    resumeDownloads: 0,
    totalMessages: 0,
    unreadMessages: 0
  };

  // Find max value in traffic list to scale our custom SVG chart
  const maxTrafficVal = data?.dailyTraffic.reduce((max, day) => Math.max(max, day.views, day.visitors), 10) || 10;

  // Render SVG Area Chart
  const renderSVGChart = () => {
    if (!data || data.dailyTraffic.length === 0) return null;

    const width = 600;
    const height = 180;
    const paddingLeft = 40;
    const paddingRight = 20;
    const paddingTop = 10;
    const paddingBottom = 25;

    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    const pointsCount = data.dailyTraffic.length;
    const stepX = chartWidth / (pointsCount - 1);

    // Generate path coords
    const viewPoints: { x: number; y: number }[] = [];
    const visitorPoints: { x: number; y: number }[] = [];

    data.dailyTraffic.forEach((day, i) => {
      const x = paddingLeft + i * stepX;
      // Views scale
      const yViews = paddingTop + chartHeight - (day.views / maxTrafficVal) * chartHeight;
      // Visitors scale
      const yVisitors = paddingTop + chartHeight - (day.visitors / maxTrafficVal) * chartHeight;

      viewPoints.push({ x, y: yViews });
      visitorPoints.push({ x, y: yVisitors });
    });

    // Generate Path Strings
    const createAreaPath = (pts: { x: number; y: number }[]) => {
      if (pts.length === 0) return "";
      let path = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 1; i < pts.length; i++) {
        path += ` L ${pts[i].x} ${pts[i].y}`;
      }
      // Close path to base line for filling
      path += ` L ${pts[pts.length - 1].x} ${paddingTop + chartHeight}`;
      path += ` L ${pts[0].x} ${paddingTop + chartHeight} Z`;
      return path;
    };

    const createLinePath = (pts: { x: number; y: number }[]) => {
      if (pts.length === 0) return "";
      let path = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 1; i < pts.length; i++) {
        path += ` L ${pts[i].x} ${pts[i].y}`;
      }
      return path;
    };

    const viewAreaPath = createAreaPath(viewPoints);
    const viewLinePath = createLinePath(viewPoints);
    const visitorLinePath = createLinePath(visitorPoints);

    return (
      <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="xMidYMid meet">
        {/* Y Axis Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
          const y = paddingTop + chartHeight * ratio;
          const val = Math.round(maxTrafficVal * (1 - ratio));
          return (
            <g key={i} className="opacity-10">
              <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="white" strokeWidth="1" strokeDasharray="4 4" />
              <text x={paddingLeft - 8} y={y + 4} fill="white" fontSize="9" textAnchor="end" fontFamily="monospace">{val}</text>
            </g>
          );
        })}

        {/* Areas & Lines */}
        <path d={viewAreaPath} fill="url(#viewAreaGradient)" opacity="0.15" />
        <path d={viewLinePath} fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d={visitorLinePath} fill="none" stroke="#10b981" strokeWidth="2" strokeDasharray="3 3" strokeLinecap="round" strokeLinejoin="round" />

        {/* Data points */}
        {viewPoints.map((pt, i) => (
          <g key={i} className="group cursor-pointer">
            <circle cx={pt.x} cy={pt.y} r="3.5" fill="#6366f1" stroke="#0f172a" strokeWidth="1.5" />
            <circle cx={visitorPoints[i].x} cy={visitorPoints[i].y} r="3" fill="#10b981" stroke="#0f172a" strokeWidth="1" />
          </g>
        ))}

        {/* X Axis Labels */}
        {data.dailyTraffic.map((day, i) => {
          const x = paddingLeft + i * stepX;
          return (
            <text key={i} x={x} y={height - 6} fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="monospace">
              {day.date}
            </text>
          );
        })}

        {/* Gradients */}
        <defs>
          <linearGradient id="viewAreaGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6366f1" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    );
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen font-sans">
      
      {/* Top Banner Dashboard bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-3 text-center sm:text-left">
            <button 
              id="dash-back-btn"
              onClick={onBackToPortfolio}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-2 rounded-lg transition-colors cursor-pointer"
              title="Return to Portfolio"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded uppercase tracking-wider font-mono">LIVE FEED ON</span>
              </div>
              <h1 className="text-xl font-black tracking-tight flex items-center space-x-2 mt-0.5 font-sans">
                <span>VIEWER ENGAGEMENT LOGS</span>
              </h1>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button 
              onClick={handleRefresh}
              disabled={refreshing}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 font-mono text-xs px-3.5 py-2 rounded-lg border border-slate-700 flex items-center space-x-2 cursor-pointer transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
              <span>{refreshing ? "REFRESHING" : "LIVE REFRESH"}</span>
            </button>
            <button 
              onClick={onBackToPortfolio}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg shadow-md cursor-pointer transition-all"
            >
              Return to Website
            </button>
          </div>
        </div>
      </div>

      {/* Main Dashboard Workspace */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Metric Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          
          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">Page Views</span>
              <Eye className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.totalViews}</p>
              <p className="text-[10px] text-emerald-400 mt-1 font-mono">⚡ +12% vs yesterday</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">Unique Visitors</span>
              <Users className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.uniqueVisitors}</p>
              <p className="text-[10px] text-emerald-400 mt-1 font-mono">⚡ 100% real-time pings</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">Session Avg</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.avgSessionDuration}<span className="text-sm font-medium text-slate-400 ml-1">m</span></p>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">Pulse tracking rate</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">CV Downloads</span>
              <Download className="w-4 h-4 text-pink-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.resumeDownloads}</p>
              <p className="text-[10px] text-indigo-400 mt-1 font-mono">📥 Print & PDF files</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">Total Inquiries</span>
              <MessageSquare className="w-4 h-4 text-teal-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.totalMessages}</p>
              <p className="text-[10px] text-teal-400 mt-1 font-mono">Stored in memory</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex flex-col justify-between ring-2 ring-indigo-500/30">
            <div className="flex justify-between items-center text-slate-400 mb-2">
              <span className="text-xs font-semibold tracking-wide uppercase">Unread Msg</span>
              <Mail className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <p className="text-2xl font-black text-white tracking-tight">{summary.unreadMessages}</p>
              <p className="text-[10px] text-red-400 mt-1 font-mono">Action required</p>
            </div>
          </div>

        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 space-x-6 mb-8 text-sm">
          <button 
            onClick={() => setActiveTab("overview")}
            className={`pb-3 font-bold transition-all ${activeTab === "overview" ? "border-b-2 border-indigo-500 text-white" : "text-slate-400 hover:text-white"}`}
          >
            Engagement Analytics Overview
          </button>
          <button 
            id="tab-messages-btn"
            onClick={() => setActiveTab("messages")}
            className={`pb-3 font-bold transition-all flex items-center space-x-1.5 ${activeTab === "messages" ? "border-b-2 border-indigo-500 text-white" : "text-slate-400 hover:text-white"}`}
          >
            <span>Contact Messages</span>
            {summary.unreadMessages > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">{summary.unreadMessages}</span>
            )}
          </button>
          <button 
            onClick={() => setActiveTab("logs")}
            className={`pb-3 font-bold transition-all ${activeTab === "logs" ? "border-b-2 border-indigo-500 text-white" : "text-slate-400 hover:text-white"}`}
          >
            Live Activity Stream
          </button>
        </div>

        {/* Tab 1: Overview */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            
            {/* Primary Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Traffic Trend SVG Area Chart */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <h3 className="font-bold text-slate-100 text-sm tracking-wide uppercase flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-indigo-400" />
                      <span>TRAFFIC ENGAGEMENT TREND (LAST 7 DAYS)</span>
                    </h3>
                    <div className="flex space-x-4 text-[10px] font-mono">
                      <div className="flex items-center space-x-1">
                        <span className="w-2.5 h-1 bg-indigo-500 rounded"></span>
                        <span className="text-slate-300">PAGE VIEWS</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <span className="w-2.5 h-1 bg-emerald-500 rounded border-dashed"></span>
                        <span className="text-slate-300">UNIQUE VISITORS</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mb-6">Aggregated interaction counts per day</p>
                </div>
                
                <div className="h-44 flex items-center justify-center">
                  {renderSVGChart()}
                </div>
              </div>

              {/* Devices Breakdown */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6">
                <h3 className="font-bold text-slate-100 text-sm tracking-wide uppercase mb-1">Device Breakdown</h3>
                <p className="text-xs text-slate-400 mb-6">Types of devices used to access your portfolio</p>

                <div className="space-y-5">
                  {data?.deviceStats.map((dev, idx) => {
                    const getIcon = (name: string) => {
                      if (name.toLowerCase() === "desktop") return <Monitor className="w-4 h-4 text-indigo-400" />;
                      if (name.toLowerCase() === "mobile") return <Smartphone className="w-4 h-4 text-emerald-400" />;
                      return <Tablet className="w-4 h-4 text-amber-400" />;
                    };
                    const getBarColor = (name: string) => {
                      if (name.toLowerCase() === "desktop") return "bg-indigo-500";
                      if (name.toLowerCase() === "mobile") return "bg-emerald-500";
                      return "bg-amber-500";
                    };

                    return (
                      <div key={idx} className="space-y-2">
                        <div className="flex justify-between text-xs font-semibold">
                          <div className="flex items-center space-x-2">
                            {getIcon(dev.name)}
                            <span className="text-slate-300 uppercase">{dev.name}</span>
                          </div>
                          <span className="text-white">{dev.percentage || 0}%</span>
                        </div>
                        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                          <div className={`h-full ${getBarColor(dev.name)} transition-all duration-1000`} style={{ width: `${dev.percentage || 0}%` }}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* Secondary Heatmaps Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Section Heatmap Bar Chart */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6">
                <h3 className="font-bold text-slate-100 text-sm tracking-wide uppercase mb-1">Section Views Heatmap</h3>
                <p className="text-xs text-slate-400 mb-6">Aggregated clicks/scroll actions on sections</p>

                <div className="space-y-4 font-mono">
                  {data && Object.entries(data.sectionViews).map(([section, views], idx) => {
                    const viewsNum = views as number;
                    const maxVal = Math.max(...(Object.values(data.sectionViews) as number[]), 1);
                    const percentageWidth = Math.round((viewsNum / maxVal) * 100);
                    return (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-bold">
                          <span className="text-slate-300 uppercase">/{section}</span>
                          <span className="text-indigo-400">{viewsNum} hits</span>
                        </div>
                        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div className="bg-indigo-600 h-full rounded-full transition-all duration-1000" style={{ width: `${percentageWidth}%` }}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Skill Engagement Chart */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6">
                <h3 className="font-bold text-slate-100 text-sm tracking-wide uppercase mb-1">Interacted Skills Matrix</h3>
                <p className="text-xs text-slate-400 mb-6">Engagement trigger points (User hovers)</p>

                <div className="space-y-4">
                  {data && Object.keys(data.skillEngagement).length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-44 text-slate-500">
                      <BarChart3 className="w-8 h-8 mb-2 opacity-50" />
                      <p className="text-xs">No hover metrics recorded yet. Go to portfolio and hover some skills!</p>
                    </div>
                  ) : (
                    data && Object.entries(data.skillEngagement)
                      .sort((a, b) => (b[1] as number) - (a[1] as number))
                      .slice(0, 5)
                      .map(([skill, count], idx) => {
                        const countNum = count as number;
                        const maxVal = Math.max(...(Object.values(data.skillEngagement) as number[]), 1);
                        const percentageWidth = Math.round((countNum / maxVal) * 100);
                        return (
                          <div key={idx} className="space-y-1.5">
                            <div className="flex justify-between text-xs font-semibold">
                              <span className="text-slate-200">{skill}</span>
                              <span className="text-emerald-400 text-xs font-mono">{countNum} hovers</span>
                            </div>
                            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                              <div className="bg-emerald-500 h-full rounded-full transition-all duration-1000" style={{ width: `${percentageWidth}%` }}></div>
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Messages */}
        {activeTab === "messages" && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="border-b border-slate-800 p-5 bg-slate-900/50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-white text-base">Contact Messages Box</h3>
                <p className="text-xs text-slate-400">Total submitted inquiries in Express memory state</p>
              </div>
              <span className="bg-indigo-500/15 text-indigo-400 text-xs font-bold px-3 py-1 rounded-full border border-indigo-500/20">
                {messages.length} messages
              </span>
            </div>

            {messages.length === 0 ? (
              <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center">
                <MessageSquare className="w-12 h-12 mb-3 text-slate-600" />
                <p className="text-sm font-semibold text-slate-400">No messages received yet</p>
                <p className="text-xs text-slate-500 mt-1">Submit a test message via the contact form on your portfolio!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-800 min-h-[400px]">
                
                {/* Message list */}
                <div className="md:col-span-1 overflow-y-auto max-h-[500px]">
                  {messages.map((msg) => (
                    <div 
                      key={msg.id}
                      onClick={() => {
                        setSelectedMessage(msg.id);
                        if (!msg.read) handleMarkAsRead(msg.id);
                      }}
                      className={`p-4 border-b border-slate-800/60 cursor-pointer transition-colors text-left relative ${
                        selectedMessage === msg.id 
                          ? "bg-slate-800/80" 
                          : "hover:bg-slate-800/30"
                      } ${!msg.read ? "border-l-4 border-indigo-500" : ""}`}
                    >
                      <div className="flex justify-between items-start">
                        <span className="font-extrabold text-sm text-slate-100 block truncate max-w-[140px]">{msg.name}</span>
                        <span className="text-[10px] font-mono text-slate-500">
                          {new Date(msg.timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                        </span>
                      </div>
                      <span className="text-xs text-slate-400 block truncate mt-0.5">{msg.email}</span>
                      <p className="text-xs text-slate-500 line-clamp-2 mt-2">{msg.message}</p>
                    </div>
                  ))}
                </div>

                {/* Message display panel */}
                <div className="md:col-span-2 p-6 flex flex-col justify-between bg-slate-900/40">
                  {selectedMessage ? (
                    (() => {
                      const msg = messages.find(m => m.id === selectedMessage);
                      if (!msg) return null;
                      return (
                        <div className="space-y-6 flex-grow flex flex-col justify-between h-full">
                          <div className="space-y-4">
                            <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-800 pb-4 space-y-2 sm:space-y-0">
                              <div>
                                <h4 className="text-lg font-black text-white">{msg.name}</h4>
                                <a href={`mailto:${msg.email}`} className="text-sm text-indigo-400 hover:underline">{msg.email}</a>
                              </div>
                              <div className="text-left sm:text-right">
                                <p className="text-xs text-slate-400 font-semibold font-mono">Date Submitted:</p>
                                <p className="text-xs text-slate-300 font-mono mt-0.5">
                                  {new Date(msg.timestamp).toLocaleString("en-US")}
                                </p>
                              </div>
                            </div>

                            <div className="bg-slate-950 p-5 rounded-xl border border-slate-800">
                              <p className="text-slate-200 text-sm whitespace-pre-wrap leading-relaxed">{msg.message}</p>
                            </div>
                          </div>

                          <div className="flex justify-end space-x-3 border-t border-slate-800 pt-4 mt-6">
                            <button 
                              onClick={() => handleDeleteMessage(msg.id)}
                              className="bg-red-500/10 hover:bg-red-500/25 border border-red-500/20 text-red-400 font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center space-x-2 cursor-pointer transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete message</span>
                            </button>
                            {!msg.read && (
                              <button 
                                onClick={() => handleMarkAsRead(msg.id)}
                                className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center space-x-2 cursor-pointer transition-colors"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Mark as read</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })()
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-500 text-center py-20">
                      <Mail className="w-10 h-10 text-slate-600 mb-2" />
                      <p className="text-sm font-semibold">Select a message from the box list to read full inquiry details.</p>
                    </div>
                  )}
                </div>

              </div>
            )}
          </div>
        )}

        {/* Tab 3: Logs */}
        {activeTab === "logs" && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="font-bold text-white text-base flex items-center space-x-2">
                  <Terminal className="w-4.5 h-4.5 text-indigo-400" />
                  <span>Real-time Activity Stream Audit</span>
                </h3>
                <p className="text-xs text-slate-400">Chronological list of tracked viewer operations in this container</p>
              </div>
              <div className="flex items-center space-x-1.5 bg-emerald-500/10 border border-emerald-500/25 px-2.5 py-1 rounded text-[10px] text-emerald-400 font-semibold font-mono animate-pulse">
                <span>MONITORING STREAM</span>
              </div>
            </div>

            <div className="space-y-3 font-mono text-xs max-h-[500px] overflow-y-auto pr-2">
              {data && data.recentActivity.length === 0 ? (
                <p className="text-center text-slate-500 py-10">Waiting for actions stream...</p>
              ) : (
                data?.recentActivity.map((log) => {
                  const getBadgeColor = (type: string) => {
                    switch (type) {
                      case "page_view":
                        return "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20";
                      case "section_view":
                        return "bg-sky-500/10 text-sky-400 border border-sky-500/20";
                      case "skill_hover":
                        return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
                      case "download_resume":
                        return "bg-pink-500/10 text-pink-400 border border-pink-500/20";
                      case "contact_click":
                      case "contact_submit":
                        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
                      default:
                        return "bg-slate-800 text-slate-400 border border-slate-700";
                    }
                  };

                  return (
                    <div 
                      key={log.id} 
                      className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded bg-slate-950/80 border border-slate-850 space-y-2 sm:space-y-0 text-left hover:border-slate-800 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getBadgeColor(log.eventType)}`}>
                          {log.eventType.toUpperCase()}
                        </span>
                        <span className="text-slate-300 font-sans text-sm font-semibold">{log.description}</span>
                      </div>
                      <span className="text-slate-500 text-[11px]">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
