/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Mail, 
  Phone, 
  MapPin, 
  FileText, 
  Download, 
  Send, 
  Terminal, 
  Award, 
  BookOpen, 
  Briefcase, 
  Globe, 
  CheckCircle, 
  Database, 
  Cpu, 
  Layers, 
  Activity,
  ArrowRight
} from "lucide-react";
import { resumeData } from "../data";
import { trackEvent } from "../utils/tracker";

interface ResumePortfolioProps {
  onNavigateToDashboard: () => void;
}

export default function ResumePortfolio({ onNavigateToDashboard }: ResumePortfolioProps) {
  const [formState, setFormState] = useState({ name: "", email: "", message: "" });
  const [submitStatus, setSubmitStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [activeSection, setActiveSection] = useState("home");
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  // Monitor scroll to update active section in header and trigger analytics events
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "skills", "experience", "education", "contact"];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            if (activeSection !== section) {
              setActiveSection(section);
              // Track section entry
              trackEvent("section_view", { section });
            }
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [activeSection]);

  const handleSkillHover = (skillName: string) => {
    setHoveredSkill(skillName);
    trackEvent("skill_hover", { skill: skillName });
  };

  const handleDownloadResume = () => {
    trackEvent("download_resume");
    // Trigger standard browser print or simulate PDF download
    window.print();
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.email || !formState.message) return;

    setSubmitStatus("submitting");
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formState,
          sessionId: sessionStorage.getItem("portfolio_session_id") || "direct"
        }),
      });

      if (response.ok) {
        setSubmitStatus("success");
        setFormState({ name: "", email: "", message: "" });
        trackEvent("contact_click", { action: "form_submission_success" });
        setTimeout(() => setSubmitStatus("idle"), 5000);
      } else {
        setSubmitStatus("error");
      }
    } catch (err) {
      console.error(err);
      setSubmitStatus("error");
    }
  };

  const getSkillCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "data analytics":
        return <Activity className="w-5 h-5 text-indigo-500" />;
      case "technical / db":
        return <Database className="w-5 h-5 text-teal-500" />;
      case "development":
        return <Cpu className="w-5 h-5 text-pink-500" />;
      default:
        return <Layers className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen font-sans">
      
      {/* Real-time Tracking Pulse Bar */}
      <div className="bg-slate-900 text-white text-xs px-4 py-2 sticky top-0 z-50 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="font-mono text-slate-300">ENGAGEMENT ENGINE: <span className="text-emerald-400">ACTIVE</span></span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-slate-400 hidden sm:inline">Active Session Analytics Enabled</span>
          <button 
            id="nav-to-dashboard-btn"
            onClick={onNavigateToDashboard}
            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-3 py-1 rounded-md transition-colors flex items-center space-x-1 cursor-pointer"
          >
            <span>Analytics Dashboard</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header Navigation */}
        <header className="flex flex-col sm:flex-row justify-between items-center border-b border-slate-200 pb-6 mb-12">
          <div className="text-center sm:text-left">
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 font-sans">{resumeData.name}</h1>
            <p className="text-indigo-600 font-medium tracking-wide text-sm mt-1 uppercase">{resumeData.title}</p>
          </div>
          <nav className="flex space-x-1 sm:space-x-2 mt-4 sm:mt-0 bg-slate-200/60 p-1 rounded-lg text-xs sm:text-sm">
            {["About", "Skills", "Experience", "Education", "Contact"].map((sec) => {
              const lowerSec = sec.toLowerCase();
              return (
                <a
                  key={sec}
                  href={`#${lowerSec}`}
                  onClick={() => trackEvent("section_view", { section: lowerSec })}
                  className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                    activeSection === lowerSec 
                      ? "bg-white text-indigo-600 shadow-sm" 
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {sec}
                </a>
              );
            })}
          </nav>
        </header>

        {/* Home / Hero Section */}
        <section id="home" className="mb-16 scroll-mt-20">
          <div className="bg-gradient-to-tr from-indigo-900 via-slate-900 to-slate-950 text-white rounded-2xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
            {/* Background design accents */}
            <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
              <div className="md:col-span-2 space-y-5">
                <div className="inline-flex items-center space-x-2 bg-indigo-500/20 text-indigo-300 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase">
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Hello World Applet</span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                  Hi, I'm Daniyel. Let's engineer digital solutions with data.
                </h2>
                <p className="text-slate-300 leading-relaxed text-sm sm:text-base">
                  {resumeData.summary}
                </p>
                <div className="flex flex-wrap gap-3 pt-2">
                  <a 
                    href="#contact"
                    id="hero-contact-btn"
                    onClick={() => trackEvent("contact_click", { location: "hero" })}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all shadow-md shadow-indigo-900/20"
                  >
                    Get in Touch
                  </a>
                  <button 
                    id="hero-download-btn"
                    onClick={handleDownloadResume}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all flex items-center space-x-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download CV / Print</span>
                  </button>
                </div>
              </div>
              <div className="flex justify-center">
                <div className="relative p-2 bg-slate-800/40 rounded-2xl border border-slate-700/60 shadow-inner">
                  {/* Decorative Profile Illustration */}
                  <svg className="w-48 h-48 rounded-xl bg-slate-900 text-indigo-400" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="40" r="18" stroke="currentColor" strokeWidth="2.5" fill="currentColor" fillOpacity="0.1" />
                    <path d="M22 80C22 66.5 31.5 58 50 58C68.5 58 78 66.5 78 80" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                    <line x1="15" y1="20" x2="25" y2="20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    <line x1="20" y1="15" x2="20" y2="25" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    <circle cx="80" cy="25" r="3" fill="#10B981" />
                    <path d="M72 15L78 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    <path d="M40 90H60" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                  <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-slate-950 font-mono text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-900 animate-pulse">
                    AVAILABLE
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Contact Badges */}
        <div id="about" className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-16 scroll-mt-20">
          <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-center space-x-4">
            <div className="bg-indigo-50 p-3 rounded-lg text-indigo-600">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-medium">Email Me Directly</p>
              <a href={`mailto:${resumeData.email}`} className="text-sm font-semibold text-slate-900 hover:underline break-all">{resumeData.email}</a>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-center space-x-4">
            <div className="bg-emerald-50 p-3 rounded-lg text-emerald-600">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-medium">Call/Phone Contact</p>
              <a href={`tel:${resumeData.phone}`} className="text-sm font-semibold text-slate-900 hover:underline">{resumeData.phone}</a>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-center space-x-4">
            <div className="bg-pink-50 p-3 rounded-lg text-pink-600">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-medium">Current Location</p>
              <p className="text-sm font-semibold text-slate-900">{resumeData.location}</p>
            </div>
          </div>
        </div>

        {/* Skills Section */}
        <section id="skills" className="mb-16 scroll-mt-20">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 pb-3 mb-8">
            <div>
              <h3 className="text-xl font-bold text-slate-900 tracking-tight flex items-center space-x-2">
                <span className="text-indigo-600">01.</span>
                <span>Technical Skills & Core Capabilities</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">Hover over any skill to trigger live engagement metrics tracking.</p>
            </div>
            {hoveredSkill && (
              <div className="mt-2 sm:mt-0 text-[11px] font-mono bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md animate-fade-in">
                Tracking hover: <span className="font-bold">{hoveredSkill}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resumeData.skills.map((cat, idx) => (
              <div 
                key={idx} 
                className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-3 mb-4">
                  {getSkillCategoryIcon(cat.category)}
                  <h4 className="font-bold text-slate-800 text-sm tracking-wide uppercase">{cat.category}</h4>
                </div>
                <div className="space-y-3">
                  {cat.items.map((skill, sIdx) => (
                    <div 
                      key={sIdx}
                      onMouseEnter={() => handleSkillHover(skill.name)}
                      className="group p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100/80 border border-slate-100 hover:border-slate-200 transition-all cursor-default"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-slate-800 text-sm group-hover:text-indigo-600 transition-colors">{skill.name}</span>
                        <span className="text-[10px] bg-slate-200/60 text-slate-600 font-semibold px-2 py-0.5 rounded">Active</span>
                      </div>
                      {skill.details && (
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2 font-sans font-normal leading-relaxed">{skill.details}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Experience & Internships Combined */}
        <section id="experience" className="mb-16 scroll-mt-20">
          <h3 className="text-xl font-bold text-slate-900 tracking-tight border-b border-slate-200 pb-3 mb-8 flex items-center space-x-2">
            <span className="text-indigo-600">02.</span>
            <span>Professional Experience & Internships</span>
          </h3>

          <div className="space-y-10">
            {/* Corporate Professional Work */}
            <div className="relative pl-6 sm:pl-8 border-l-2 border-indigo-600">
              <div className="absolute -left-2.5 top-0 w-5 h-5 rounded-full bg-indigo-600 border-4 border-slate-50 flex items-center justify-center"></div>
              
              <div className="bg-white rounded-xl border border-slate-200/80 p-5 sm:p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-4">
                  <div>
                    <h4 className="text-base sm:text-lg font-bold text-slate-900">{resumeData.experience[0].role}</h4>
                    <p className="text-sm font-semibold text-indigo-600 mt-0.5">{resumeData.experience[0].company}</p>
                  </div>
                  <span className="inline-block mt-2 sm:mt-0 text-xs bg-indigo-50 text-indigo-700 border border-indigo-100 px-3 py-1 rounded-full font-semibold">
                    {resumeData.experience[0].period}
                  </span>
                </div>
                <ul className="space-y-2.5">
                  {resumeData.experience[0].highlights.map((highlight, hIdx) => (
                    <li key={hIdx} className="flex items-start space-x-3 text-sm text-slate-600 leading-relaxed">
                      <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Internships Timeline Items */}
            {resumeData.internships.map((intern, iIdx) => (
              <div key={iIdx} className="relative pl-6 sm:pl-8 border-l-2 border-slate-200">
                <div className="absolute -left-1.5 top-0 w-3 h-3 rounded-full bg-slate-300 border-2 border-slate-50"></div>
                
                <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm">
                  <div className="flex items-center space-x-2 mb-2">
                    <Award className="w-4.5 h-4.5 text-amber-500" />
                    <h4 className="text-sm sm:text-base font-bold text-slate-950 uppercase tracking-tight">{intern.role}</h4>
                  </div>
                  <p className="text-xs text-slate-500 font-semibold mb-2 uppercase tracking-wider">Academic Internship</p>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {intern.details}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="mb-16 scroll-mt-20">
          <h3 className="text-xl font-bold text-slate-900 tracking-tight border-b border-slate-200 pb-3 mb-8 flex items-center space-x-2">
            <span className="text-indigo-600">03.</span>
            <span>Education History</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resumeData.education.map((edu, idx) => (
              <div 
                key={idx}
                className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow relative"
              >
                <div className="absolute top-4 right-4 bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded">
                  {edu.period}
                </div>
                <div className="bg-indigo-50 w-10 h-10 rounded-lg flex items-center justify-center text-indigo-600 mb-4">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm sm:text-base leading-tight mb-1">{edu.degree}</h4>
                <p className="text-xs font-semibold text-indigo-600 mb-3">{edu.institution}</p>
                <p className="text-xs text-slate-500 font-sans leading-relaxed">{edu.details}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Languages & Extras */}
        <section className="mb-16">
          <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-lg">
            <div className="flex items-center space-x-2.5 mb-6 border-b border-slate-800 pb-4">
              <Globe className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold tracking-wide uppercase">Languages Spoken</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {resumeData.languages.map((lang, lIdx) => (
                <div key={lIdx} className="bg-slate-800/50 rounded-xl p-4 border border-slate-800 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-100 text-sm">{lang.language}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">{lang.level}</p>
                  </div>
                  <span className={`w-2.5 h-2.5 rounded-full ${
                    lang.level.toLowerCase() === 'native' ? 'bg-emerald-400' :
                    lang.level.toLowerCase() === 'proficient' ? 'bg-indigo-400' : 'bg-blue-400'
                  }`}></span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section & Form */}
        <section id="contact" className="scroll-mt-20">
          <h3 className="text-xl font-bold text-slate-900 tracking-tight border-b border-slate-200 pb-3 mb-8 flex items-center space-x-2">
            <span className="text-indigo-600">04.</span>
            <span>Get in Touch / Inquiry</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
            <div className="md:col-span-2 space-y-4">
              <h4 className="font-extrabold text-slate-900 text-base">Let's connect on a project!</h4>
              <p className="text-sm text-slate-600 leading-relaxed">
                Whether you have an internship role, freelance work, full-time position or simply want to check my analytics tracking capability, shoot me a message! Your submission is stored directly in my Express backend.
              </p>
              <div className="space-y-2 text-xs text-slate-500 font-mono">
                <p>⚡ STACK: React 19, Tailwind, Express</p>
                <p>📍 COIMBATORE, TAMIL NADU, INDIA</p>
                <p>📞 +91 6380852219</p>
              </div>
            </div>

            <div className="md:col-span-3">
              <form onSubmit={handleContactSubmit} className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-sm space-y-4">
                <div>
                  <label htmlFor="name" className="block text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5">Full Name</label>
                  <input 
                    type="text" 
                    id="name"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    placeholder="Sathish Kumar"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5">Email Address</label>
                  <input 
                    type="email" 
                    id="email"
                    required
                    value={formState.email}
                    onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    placeholder="sathish.hr@infotech.in"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5">Your Message</label>
                  <textarea 
                    id="message"
                    required
                    rows={4}
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    placeholder="Type your proposal or message here..."
                  />
                </div>

                {submitStatus === "success" && (
                  <div className="bg-emerald-50 text-emerald-800 text-xs font-semibold p-3.5 rounded-lg border border-emerald-100 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                    <span>Thank you! Your message was submitted and logged successfully. Visit the Dashboard to read it.</span>
                  </div>
                )}

                {submitStatus === "error" && (
                  <div className="bg-red-50 text-red-800 text-xs font-semibold p-3.5 rounded-lg border border-red-100">
                    Oops! There was an issue submitting your message. Please try again.
                  </div>
                )}

                <button 
                  type="submit"
                  id="contact-submit-btn"
                  disabled={submitStatus === "submitting"}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 text-white font-semibold py-2.5 rounded-lg text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitStatus === "submitting" ? "Sending Message..." : "Send Secure Message"}</span>
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-20 border-t border-slate-200 pt-8 text-center text-xs text-slate-500">
          <p>© 2026 {resumeData.name}. All rights reserved.</p>
          <p className="mt-1">
            Engineered with React 19 & Tailwind CSS. Powered by custom in-memory node-express analytics collection.
          </p>
        </footer>

      </div>
    </div>
  );
}
