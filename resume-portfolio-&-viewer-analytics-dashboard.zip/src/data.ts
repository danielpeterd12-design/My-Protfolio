import { ResumeData } from "./types";

export const resumeData: ResumeData = {
  name: "DANIYEL G.",
  title: "IT Specialist & Web Developer",
  location: "Coimbatore, Tamil Nadu",
  phone: "6380852219",
  email: "danielpeterd12@gmail.com",
  summary: "Motivated IT student with a strong technical foundation in Data Analytics, Web Development, and Operations. Experienced in quality control, billing software, and database management. Eager to apply technical skills in software development and data-driven decision-making.",
  skills: [
    {
      category: "Data Analytics",
      items: [
        { name: "Advanced Excel", details: "Logical Formula, pmt, ppmt, ipmt, Data Validation, Vlookup, Hlookup" },
        { name: "Power BI", details: "Interactive dashboard creation & data visualization" }
      ]
    },
    {
      category: "Technical / DB",
      items: [
        { name: "MySQL", details: "Queries, Table Management, performance schema" },
        { name: "Python", details: "Basics of scripting & core structures" },
        { name: "HTML/CSS", details: "Responsive semantic markup & custom layouts" }
      ]
    },
    {
      category: "Development",
      items: [
        { name: "Web Development", details: "Full-stack React, Express, modern CSS tailwind systems" },
        { name: "Flutter App Development", details: "Responsive UI/UX design, mobile client architecture" }
      ]
    },
    {
      category: "Operations",
      items: [
        { name: "Quality Control Inspection", details: "Material standard verification" },
        { name: "Billing Software Operations", details: "Store inventory, transaction logs, records" },
        { name: "Data Entry", details: "Accurate database logs & records" }
      ]
    }
  ],
  experience: [
    {
      company: "Premier Precision Engineering Roll Company",
      role: "Computer Executive & Quality Checker",
      period: "Ongoing / Professional Experience",
      highlights: [
        "Executed quality control inspections to ensure production standards are strictly met.",
        "Managed computer executive duties, client billing software operations, and precise data entry pipelines."
      ]
    }
  ],
  internships: [
    {
      role: "Ethical Hacking Intern",
      details: "Gained hands-on knowledge in cybersecurity concepts, vulnerability assessment, network mapping, and security auditing standard workflows."
    },
    {
      role: "Flutter App Development Intern",
      details: "Developed key skills in building cross-platform mobile apps, reactive state management, and high-fidelity UI/UX design principles."
    }
  ],
  education: [
    {
      degree: "B.Sc. Information Technology",
      institution: "SNR Sons College of Arts and Science, Coimbatore",
      period: "2024 – 2027",
      details: "Pursuing bachelor's degree with current Cumulative GPA of 7.0/10.0"
    },
    {
      degree: "Higher Secondary Education",
      institution: "Perks Matric Higher Secondary School, Coimbatore",
      period: "Completed",
      details: "Graduated with 66% cumulative final grade"
    }
  ],
  languages: [
    { language: "Tamil", level: "Native" },
    { language: "English", level: "Proficient" },
    { language: "Hindi", level: "Intermediate" }
  ]
};
