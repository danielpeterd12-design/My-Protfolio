/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ResumeData {
  name: string;
  title: string;
  location: string;
  phone: string;
  email: string;
  summary: string;
  skills: {
    category: string;
    items: { name: string; details?: string }[];
  }[];
  experience: {
    company: string;
    role: string;
    period: string;
    highlights: string[];
  }[];
  internships: {
    role: string;
    details: string;
  }[];
  education: {
    degree: string;
    institution: string;
    period: string;
    details: string;
  }[];
  languages: {
    language: string;
    level: string;
  }[];
}

export interface AnalyticsSummary {
  totalViews: number;
  uniqueVisitors: number;
  avgSessionDuration: string;
  resumeDownloads: number;
  totalMessages: number;
  unreadMessages: number;
}

export interface AnalyticsReport {
  summary: AnalyticsSummary;
  sectionViews: Record<string, number>;
  skillEngagement: Record<string, number>;
  dailyTraffic: { date: string; views: number; visitors: number }[];
  deviceStats: { name: string; percentage: number }[];
  browserStats: { name: string; count: number }[];
  recentActivity: { id: string; timestamp: string; eventType: string; description: string }[];
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
  read: boolean;
}
