/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Helper to generate or retrieve a persistent session identifier
export function getOrCreateSessionId(): string {
  if (typeof window === "undefined") return "server-side";
  let sessionId = sessionStorage.getItem("portfolio_session_id");
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    sessionStorage.setItem("portfolio_session_id", sessionId);
  }
  return sessionId;
}

// Low-overhead client tracker helper
export async function trackEvent(eventType: string, eventData?: any) {
  try {
    const sessionId = getOrCreateSessionId();
    // Fire-and-forget sending to API
    fetch("/api/analytics/event", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        sessionId,
        eventType,
        eventData,
      }),
    }).catch((e) => console.warn("Analytics event tracking failed silently:", e));
  } catch (error) {
    console.warn("Analytics error:", error);
  }
}

// Send periodic heartbeat pings to calculate accurate session duration
export function startSessionPingInterval(): () => void {
  // Page entry trigger
  trackEvent("page_view");

  // Pulse ping every 30s
  const intervalId = setInterval(() => {
    trackEvent("session_ping");
  }, 30000);

  // Return clean-up function
  return () => {
    clearInterval(intervalId);
  };
}
